package com.aluracursos.screenmatch3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Screenmatch3Application {

	public static void main(String[] args) {
		SpringApplication.run(Screenmatch3Application.class, args);
	}

}
