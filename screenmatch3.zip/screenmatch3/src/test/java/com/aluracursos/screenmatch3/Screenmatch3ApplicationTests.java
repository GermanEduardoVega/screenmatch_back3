package com.aluracursos.screenmatch3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Screenmatch3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
